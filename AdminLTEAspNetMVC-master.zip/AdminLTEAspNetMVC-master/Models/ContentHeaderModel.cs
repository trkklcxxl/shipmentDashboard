﻿namespace AspMVCAdminLTE.Models
{
    public class ContentHeaderModel
    {
        public string Title { get; set; }
    }
}