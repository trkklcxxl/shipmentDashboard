﻿namespace AspMVCAdminLTE.Entity.Enums
{
    public enum Gender
    {
        Male = 1,
        Female = 2
    }
}