﻿namespace AspMVCAdminLTE.Entity.Enums
{
    public enum UserRole
    {
        Admin,
        Normal
    }
}